export interface   Employee {
  employeeID: string,
  firstName:string,
  lastName: string,
  role: string,
  department: string,
  dateOfJoining: string,
  performanceRating: string,
  id:number
}

