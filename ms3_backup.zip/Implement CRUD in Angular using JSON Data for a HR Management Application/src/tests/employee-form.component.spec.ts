import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { EmployeeFormComponent } from 'src/app/employee-form/employee-form.component';
import { FormBuilder, ReactiveFormsModule } from "@angular/forms";
import { EmployeeService } from 'src/app/services/employee.service';
import { Router } from '@angular/router';
import { of } from 'rxjs';


describe('EmployeeFormComponent', () => {
  let component: EmployeeFormComponent;
  let fixture: ComponentFixture<EmployeeFormComponent>;
  let employeeService: jasmine.SpyObj<EmployeeService>;
  let router: jasmine.SpyObj<Router>;

  beforeEach(async () => {
    const employeeServiceSpy = jasmine.createSpyObj('EmployeeService', ['addEmployees']);
    const routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);
    await TestBed.configureTestingModule({
      declarations: [ EmployeeFormComponent ],
      imports: [ReactiveFormsModule],
      providers: [
        { provide: EmployeeService, useValue: employeeServiceSpy },
        { provide: Router, useValue: routerSpy }
      ]
    })
    .compileComponents();
    employeeService = TestBed.inject(EmployeeService) as jasmine.SpyObj<EmployeeService>;
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;

    fixture = TestBed.createComponent(EmployeeFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("should emit an employee when the form is submitted with valid data", fakeAsync(() => {
    const formBuilder: FormBuilder = TestBed.inject(FormBuilder);
    const employee = {
        "employeeID": "001",
        "firstName": "Ansh",
        "lastName": "pandey",
        "role": "Manager",
        "department": "Civil",
        "dateOfJoining": "2000-01-01",
        "performanceRating": "A",
        "id": 1
      
    };

    // Set up the form with valid data
    component.employeeForm = formBuilder.group({
      employeeID: [employee.employeeID],
      firstName: [employee.firstName],
      lastName: [employee.lastName],
      role: [employee.role],
      department: [employee.department],
      dateOfJoining: [employee.dateOfJoining],
      performanceRating: [employee.performanceRating],
      id: 1
  
    });

    component.employeeForm.setValue(employee);

    // Stub the addEmployee method of the employeeService to return an observable of empty object
    employeeService.addEmployees.and.returnValue(of({})); // Corrected method name here

    // Call submitForm
    component.onSubmit();

    // Verify that addEmployee method was called with the correct data
    expect(employeeService.addEmployees).toHaveBeenCalledWith(employee); // Corrected method name here

    // Ensure router navigation has occurred
    expect(router.navigateByUrl).toHaveBeenCalledWith('employee-list');

    // Advance the fakeAsync zone to ensure any asynchronous operations are complete
    tick();

    // Ensure router navigation has occurred
    expect(router.navigateByUrl).toHaveBeenCalledWith('employee-list');
  }));

});
