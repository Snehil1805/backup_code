import { ComponentFixture, TestBed } from "@angular/core/testing";
import { map, of, throwError } from "rxjs";

import { EmployeeListComponent } from "src/app/employee-list/employee-list.component";
import { Employee } from "src/app/models/Employee";
import { EmployeeService } from "src/app/services/employee.service";
import { EmployeeDetailsComponent } from "src/app/employee-details/employee-details.component";
import { EmployeeFormComponent } from "src/app/employee-form/employee-form.component";



    describe("EmployeeListComponent", () => {
      let component: EmployeeListComponent;
      let fixture: ComponentFixture<EmployeeListComponent>;
      let employeeService: jasmine.SpyObj<EmployeeService>;
    
      beforeEach(() => {
        employeeService = jasmine.createSpyObj("EmployeeService", [
          "getEmployees",
          "addEmployee",
        ]);

    TestBed.configureTestingModule({
      declarations: [
        EmployeeListComponent,
        EmployeeFormComponent,
        EmployeeDetailsComponent,
      ],
      providers: [{ provide: EmployeeService, useValue: employeeService }],
    });

    fixture = TestBed.createComponent(EmployeeListComponent);
    component = fixture.componentInstance;
  });


  it("should create", () => {
    expect(component).toBeTruthy();
  });

 
  it("should fetch employees on ngOnInit", () => {
    const mockEmployee: Employee[] = [
      {
        "employeeID": "001",
        "firstName": "Ansh",
        "lastName": "pandey",
        "role": "Manager",
        "department": "Civil",
        "dateOfJoining": "2000-01-01",
        "performanceRating": "A",
        id:1
        
      },
    ];

    employeeService.getEmployees.and.returnValue(of(mockEmployee));

    fixture.detectChanges(); // Trigger ngOnInit

    expect(component.employee$).toBeTruthy();
    component.employee$.subscribe((employee: Employee[]) => {
      expect(employee).toEqual(mockEmployee);
    });
  });

  it("should handle errors when fetching events on ngOnInit", () => {
    employeeService.getEmployees.and.returnValue(throwError("Error"));

    fixture.detectChanges(); // Trigger ngOnInit

    expect(component.employee$).toBeTruthy();
    component.employee$.subscribe({
      error: (error: any) => {
        expect(error).toEqual("Error");
      },
    });
  });



    it("should search employee", () => {
      const mockEmployee: Employee[] = [
        {
          "employeeID": "001",
          "firstName": "Ansh",
          "lastName": "pandey",
          "role": "Manager",
          "department": "Civil",
          "dateOfJoining": "2000-01-01",
          "performanceRating": "A",
          id:1
      }
      ];

employeeService.getEmployees.and.returnValue(of(mockEmployee));
component.ngOnInit();

component.searchEmp({ target: { value: "001" } });

component.filteredEmployees$.subscribe((FilterEmp) => {
  expect(FilterEmp.length).toBe(1);
  expect(FilterEmp[0].employeeID).toBe("001");
});
});
});

