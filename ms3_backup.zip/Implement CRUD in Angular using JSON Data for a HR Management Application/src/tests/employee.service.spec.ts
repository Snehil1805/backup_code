import { TestBed, inject } from "@angular/core/testing";
import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
import { EmployeeService } from "src/app/services/employee.service";
import { Employee } from "src/app/models/Employee";
import { environment } from "src/environments/environment";

describe("EmployeeService", () => {
  let service: EmployeeService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [EmployeeService],
    });

    service = TestBed.inject(EmployeeService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify(); // Verify that there are no outstanding HTTP requests.
  });

  it("should be created", () => {
    expect(service).toBeTruthy();
  });

  it("should retrieve employees from the API via GET", () => {
    const mockEmployee: Employee[] = [
      {
        "employeeID": "001",
        "firstName": "Ansh",
        "lastName": "pandey",
        "role": "Manager",
        "department": "Civil",
        "dateOfJoining": "2000-01-01",
        "performanceRating": "A",
        id:1
        
      },
    ];

    service.getEmployees().subscribe((employee: Employee[]) => {
      expect(employee).toEqual(mockEmployee);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/employee`);
    expect(req.request.method).toBe("GET");
    req.flush(mockEmployee);
  });

  it("should add a employee via POST", () => {
    const newEmployee: Employee = {
      "employeeID": "001",
      "firstName": "Ansh",
      "lastName": "pandey",
      "role": "Manager",
      "department": "Civil",
      "dateOfJoining": "2000-01-01",
      "performanceRating": "A",
      id:1
    }

    service.addEmployees(newEmployee).subscribe(() => {
      // Do any necessary assertions here
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/employee`);
    expect(req.request.method).toBe("POST");
    expect(req.request.body).toEqual(newEmployee);

    // Simulate a successful HTTP response
    req.flush({});
  });

  it("should retrieve a product by ID via GET", () => {
    const mockEmployee: Employee []= [{
      "employeeID": "001",
      "firstName": "Ansh",
      "lastName": "pandey",
      "role": "Manager",
      "department": "Civil",
      "dateOfJoining": "2000-01-01",
      "performanceRating": "A",
      id:1
    }]

    service.getEmployee(1).subscribe((employee) => {
      expect(employee).toEqual(mockEmployee);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/employee/1`);
    expect(req.request.method).toBe("GET");
    req.flush(mockEmployee);
  });
});
