export interface BankAccount {
  id: number;
  accountHolder: string;
  accountType: string;
  openingDate: string;
  balance: number;
  status: string;

}
