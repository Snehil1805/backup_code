import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BankaccountListComponent } from './account-list/bankaccount-list.component';
import { BankaccountDetailsComponent } from './account-details/bankaccount-details.component';
import { BankaccountFormComponent } from './account-form/bankaccount-form.component';

const routes: Routes = [
  { path: 'bankaccount-list', component: BankaccountListComponent },
  { path: 'bankaccount-details/:id', component: BankaccountDetailsComponent },
  { path: 'bankaccount-form', component: BankaccountFormComponent },
  { path: '', redirectTo: '/bankaccount-list', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
