import { Component, EventEmitter, OnInit, Output } from "@angular/core";
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  ValidationErrors,
  Validators,
} from "@angular/forms";
import { BankAccount } from "../models/BankAccount";
import { BankAccountService } from "../services/bankAccount.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-bankAccount-form",
  templateUrl: "./bankaccount-form.component.html",
  styleUrls: ["./bankaccount-form.component.scss"],
})
export class BankaccountFormComponent implements OnInit {
  bankAccountForm: FormGroup;


  constructor(private fb: FormBuilder,private bankAccountService: BankAccountService, private router:Router) {}

  ngOnInit(): void {
    // Initialize the form with validators
    this.bankAccountForm = this.fb.group({
      accountHolder: ["", [Validators.required]],
      accountType: ["", [Validators.required]],
      openingDate: ["", [Validators.required, this.dateValidator]],
      balance: ["", [Validators.required]],
      status: ["", [Validators.required]],

    });
  }

  dateValidator(control: AbstractControl): ValidationErrors | null {
    const datePattern = /^\d{4}-\d{2}-\d{2}$/;

    if (!datePattern.test(control.value)) {
      return { invalidDate: true };
    }

    return null;
  }

  // Function to submit the form
  onSubmit() {
    if (this.bankAccountForm.valid) {
      // Form is valid, you can submit it
      this.bankAccountService.addBankAccount(this.bankAccountForm.value).subscribe((res) => {
        this.router.navigateByUrl('/bankaccount-list')
      });
    } else {
      // Form is invalid, display error messages
      this.markFormGroupTouched(this.bankAccountForm);
    }
  }

  // Helper function to mark all controls in the form group as touched
  markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach((control) => {
      control.markAsTouched();

      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }
}
