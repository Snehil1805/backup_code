import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { BankAccount } from '../models/BankAccount';
@Injectable({
  providedIn: 'root'
})
export class BankAccountService {

  private apiUrl = environment.apiUrl; 

  constructor(private http: HttpClient) {}

  getBankAccounts(): Observable<any> {
    return this.http.get(`${this.apiUrl}/bankAccounts`);
  }

  getBankAccount(id: number): any {
    return this.http.get(`${this.apiUrl}/bankAccounts/${id}`);
  }

  addBankAccount(bankAccount: BankAccount): Observable<any> {
    return this.http.post(`${this.apiUrl}/bankAccounts`, bankAccount);
  }
  deleteBankAccount(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/bankAccounts/${id}`);
  }
}
