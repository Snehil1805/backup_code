import { Component, OnInit } from '@angular/core';
import { Observable, map, of } from 'rxjs';
import { BankAccountService } from '../services/bankAccount.service';
import { BankAccount } from '../models/BankAccount';

@Component({
  selector: 'app-bankAccount-list',
  templateUrl: './bankaccount-list.component.html',
  styleUrls: ['./bankaccount-list.component.scss']
})
export class BankaccountListComponent implements OnInit {
  filteredBankAccounts$: Observable<BankAccount[]> = of([]);
  bankAccounts$: Observable<BankAccount[]> = of([]);
  addNewBankAccount: boolean = false;

  constructor(private bankAccountService: BankAccountService) { }

  ngOnInit(): void {
    this.getBankAccounts();
  }

 

  getBankAccounts() {
    this.bankAccounts$ = this.bankAccountService.getBankAccounts().pipe(
      map((bankAccounts) => 
        bankAccounts.sort((a:any, b:any) => a.accountHolder.localeCompare(b.accountHolder)) // Sort by accountHolder
      )
    );
    this.filteredBankAccounts$ = this.bankAccounts$;
    console.log(this.bankAccounts$)
  }

  searchBankAccounts(event: any) {
    const searchTerm = event.target.value.trim();
    if (!searchTerm) {
      this.filteredBankAccounts$ = this.bankAccounts$;
      return;
    }
    this.filteredBankAccounts$ = this.bankAccounts$.pipe(
      map((bankAccounts) => {
        return bankAccounts.filter(
          (event) =>
            event.id.toString().includes(searchTerm) ||
            event.accountHolder.includes(searchTerm) ||
            event.accountType.includes(searchTerm)
        );
      })
    );
  }
  delete(event:any)
  {
    this.bankAccountService.deleteBankAccount(event.id).subscribe((data)=>{
      this.getBankAccounts();
    });
    
  }

}
