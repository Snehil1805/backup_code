import { Component, Input, OnInit } from '@angular/core';
import { BankAccount } from '../models/BankAccount';
import { Observable, of } from 'rxjs';
import { BankAccountService } from '../services/bankAccount.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-bankAccount-details',
  templateUrl: './bankaccount-details.component.html',
  styleUrls: ['./bankaccount-details.component.scss']
})
export class BankaccountDetailsComponent implements OnInit {

  bankAccount: Observable<BankAccount>; 
  constructor(private bankAccountService: BankAccountService,private route: ActivatedRoute){

  }
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      // Access parameters from the URL
      const id = params['id']; // Assuming your parameter is named 'id'
     this.getEvent(id);
      
    });
   
  }
  getEvent(id: any) {
    this.bankAccount = this.bankAccountService.getBankAccount(id);
  }
}