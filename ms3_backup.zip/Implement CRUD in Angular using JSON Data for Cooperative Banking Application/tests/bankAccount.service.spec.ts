import { TestBed, inject } from "@angular/core/testing";
import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
import { BankAccountService } from "../app/services/bankAccount.service";
import { BankAccount } from "../app/models/BankAccount";
import { environment } from "src/environments/environment";

describe("BankAccountService", () => {
  let service: BankAccountService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BankAccountService],
    });

    service = TestBed.inject(BankAccountService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify(); // Verify that there are no outstanding HTTP requests.
  });

  it("should be created", () => {
    expect(service).toBeTruthy();
  });

  it("should retrieve events from the API via GET", () => {
    const mockBankAccounts: BankAccount[] = [
      {
        id: 1,
        accountHolder: "John Doe",
        accountType: "Savings",
        openingDate: "2022-07-01",
        balance: 2500,
        status: "Active"
      },
      {
        id: 2,
        accountHolder: "Jane Smith",
        accountType: "Loan",
        openingDate: "2022-07-10",
        balance: -10000,
        status: "Active"
      }
    ];

    service.getBankAccounts().subscribe((bankAccounts: BankAccount[]) => {
      expect(bankAccounts).toEqual(mockBankAccounts);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/bankAccounts`);
    expect(req.request.method).toBe("GET");
    req.flush(mockBankAccounts);
  });

  it("should add a bankAccount via POST", () => {
    const newBankAccount: BankAccount = {
      id: 1,
      accountHolder: "John Doe",
      accountType: "Savings",
      openingDate: "2022-07-01",
      balance: 2500,
      status: "Active"
    }

    service.addBankAccount(newBankAccount).subscribe(() => {
      // Do any necessary assertions here
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/bankAccounts`);
    expect(req.request.method).toBe("POST");
    expect(req.request.body).toEqual(newBankAccount);

    // Simulate a successful HTTP response
    req.flush({});
  });

  it("should retrieve a product by ID via GET", () => {
    const mockEvent: BankAccount = {
      id: 1,
      accountHolder: "John Doe",
      accountType: "Savings",
      openingDate: "2022-07-01",
      balance: 2500,
      status: "Active"
    }

    service.getBankAccount(1).subscribe((bankAccount: BankAccount) => {
      expect(bankAccount.id).toEqual(mockEvent.id);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/bankAccounts/1`);
    expect(req.request.method).toBe("GET");
    req.flush(mockEvent);
  });

  it("should delete a bankAccount by ID via DELETE", () => {
    const id = 1;

    service.deleteBankAccount(id).subscribe(() => {
      // Do any necessary assertions here
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/bankAccounts/${id}`);
    expect(req.request.method).toBe("DELETE");

    // Simulate a successful HTTP response
    req.flush({});
  });
});
