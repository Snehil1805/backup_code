import { ComponentFixture, TestBed } from "@angular/core/testing";
import { map, of, throwError } from "rxjs";

import { BankaccountListComponent } from "../app/account-list/bankaccount-list.component";
import { BankAccountService } from "../app/services/bankAccount.service";
import { BankAccount } from "src/app/models/BankAccount";
import { BankaccountDetailsComponent } from "src/app/account-details/bankaccount-details.component";
import { BankaccountFormComponent } from "src/app/account-form/bankaccount-form.component";

describe("BankaccountListComponent", () => {
  let component: BankaccountListComponent;
  let fixture: ComponentFixture<BankaccountListComponent>;
  let bankAccountService: jasmine.SpyObj<BankAccountService>;

  beforeEach(() => {
    bankAccountService = jasmine.createSpyObj("BankAccountService", [
      "getBankAccounts",
      "addBankAccount",
    ]);

    TestBed.configureTestingModule({
      declarations: [
        BankaccountListComponent,
        BankaccountFormComponent,
        BankaccountDetailsComponent,
      ],
      providers: [{ provide: BankAccountService, useValue: bankAccountService }],
    });

    fixture = TestBed.createComponent(BankaccountListComponent);
    component = fixture.componentInstance;
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should fetch and sort accounts by accountHolder on ngOnInit", () => {
    const mockBankAccounts: BankAccount[] = [
      {
        id: 1,
        accountHolder: "John Doe",
        accountType: "Savings",
        openingDate: "2022-07-01",
        balance: 2500,
        status: "Active",
      },
      {
        id: 2,
        accountHolder: "Jane Smith",
        accountType: "Loan",
        openingDate: "2022-07-10",
        balance: -10000,
        status: "Active",
      },
      {
        id: 3,
        accountHolder: "Alice Brown",
        accountType: "Current",
        openingDate: "2023-01-15",
        balance: 5000,
        status: "Inactive",
      },
    ];

    bankAccountService.getBankAccounts.and.returnValue(of(mockBankAccounts));

    fixture.detectChanges(); // Trigger ngOnInit

    expect(component.bankAccounts$).toBeTruthy();
    component.bankAccounts$.subscribe((bankAccounts: BankAccount[]) => {
      expect(bankAccounts).toEqual([
        {
          id: 3,
          accountHolder: "Alice Brown",
          accountType: "Current",
          openingDate: "2023-01-15",
          balance: 5000,
          status: "Inactive",
        },
        {
          id: 2,
          accountHolder: "Jane Smith",
          accountType: "Loan",
          openingDate: "2022-07-10",
          balance: -10000,
          status: "Active",
        },
        {
          id: 1,
          accountHolder: "John Doe",
          accountType: "Savings",
          openingDate: "2022-07-01",
          balance: 2500,
          status: "Active",
        },
      ]);
    });
  });

  it("should handle errors when fetching accounts on ngOnInit", () => {
    bankAccountService.getBankAccounts.and.returnValue(throwError("Error"));

    fixture.detectChanges(); // Trigger ngOnInit

    expect(component.bankAccounts$).toBeTruthy();
    component.bankAccounts$.subscribe({
      error: (error: any) => {
        expect(error).toEqual("Error");
      },
    });
  });

  it("should search accounts", () => {
    const bankAccounts: BankAccount[] = [
      {
        id: 1,
        accountHolder: "John Doe",
        accountType: "Savings",
        openingDate: "2022-07-01",
        balance: 2500,
        status: "Active",
      },
      {
        id: 2,
        accountHolder: "Jane Smith",
        accountType: "Loan",
        openingDate: "2022-07-10",
        balance: -10000,
        status: "Active",
      },
    ];

    bankAccountService.getBankAccounts.and.returnValue(of(bankAccounts));
    component.ngOnInit();

    component.searchBankAccounts({ target: { value: "John Doe" } });

    component.filteredBankAccounts$.subscribe((filteredBankAccounts) => {
      expect(filteredBankAccounts.length).toBe(1);
      expect(filteredBankAccounts[0].accountHolder).toBe("John Doe");
    });
  });
});
