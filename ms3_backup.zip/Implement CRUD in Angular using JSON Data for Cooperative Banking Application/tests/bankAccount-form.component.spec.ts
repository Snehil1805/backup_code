import { ComponentFixture, TestBed, fakeAsync, tick } from "@angular/core/testing";
import { FormBuilder, ReactiveFormsModule } from "@angular/forms";
import { BankaccountFormComponent } from "../app/account-form/bankaccount-form.component";
import { BankAccountService } from "src/app/services/bankAccount.service";
import { Router } from "@angular/router";
import { of } from "rxjs";

describe("BankaccountFormComponent", () => {
  let component: BankaccountFormComponent;
  let fixture: ComponentFixture<BankaccountFormComponent>;
  let bankAccountService: jasmine.SpyObj<BankAccountService>; // Corrected the variable name here
  let router: jasmine.SpyObj<Router>;

  beforeEach(() => {
    const bankAccountServiceSpy = jasmine.createSpyObj('BankAccountService', ['addBankAccount']); // Corrected the variable name here
    const routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);
    TestBed.configureTestingModule({
      declarations: [BankaccountFormComponent],
      imports: [ReactiveFormsModule],
      providers: [
        { provide: BankAccountService, useValue: bankAccountServiceSpy }, // Corrected the variable name here
        { provide: Router, useValue: routerSpy }
      ]
    });

    fixture = TestBed.createComponent(BankaccountFormComponent);
    component = fixture.componentInstance;
    bankAccountService = TestBed.inject(BankAccountService) as jasmine.SpyObj<BankAccountService>; // Corrected the variable name here
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should emit a bankAccount when the form is submitted with valid data" , fakeAsync(() => {
    const formBuilder: FormBuilder = TestBed.inject(FormBuilder);
    const bankAccount = {
      "id": 1,
      "accountHolder": "Alice Johnson",
      "accountType": "Checking",
      "openingDate": "2023-09-29",
      "balance": 7500,
      "status": "Active"
    };

    // Set up the form with valid data
    component.bankAccountForm = formBuilder.group({
      id: 1,
      accountHolder: [bankAccount.accountHolder],
      accountType: [bankAccount.accountType],
      openingDate: [bankAccount.openingDate],
      balance: [bankAccount.balance],
      status: [bankAccount.status],
    });

    component.bankAccountForm.setValue(bankAccount);

    // Stub the addBankAccount method of the bankAccountService to return an observable of empty object
    bankAccountService.addBankAccount.and.returnValue(of({}));

    // Call submitForm
    component.onSubmit();

    // Verify that addBankAccount method was called with the correct data
    expect(bankAccountService.addBankAccount).toHaveBeenCalledWith(bankAccount);

    // Ensure router navigation has occurred
    expect(router.navigateByUrl).toHaveBeenCalledWith('/bankaccount-list');

    // Advance the fakeAsync zone to ensure any asynchronous operations are complete
    tick();

    // Ensure router navigation has occurred
    expect(router.navigateByUrl).toHaveBeenCalledWith('/bankaccount-list');
  }));
});
