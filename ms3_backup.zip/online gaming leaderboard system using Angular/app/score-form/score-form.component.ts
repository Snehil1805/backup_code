import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { ScoreService } from '../services/score.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-score-form',
  templateUrl: './score-form.component.html',
  styleUrls: ['./score-form.component.scss']
})
export class ScoreFormComponent implements OnInit {
  scoreForm: FormGroup;


  constructor(private fb: FormBuilder,private scoreService: ScoreService, private route:Router) { }

  ngOnInit(): void {
    // Initialize the form with validators
    this.scoreForm = this.fb.group({
      playerName: ['', [Validators.required]],
      score: ['', [Validators.required, this.nonNegativeValidator]],
      submissionDate: ['', [Validators.required,this.dateValidator]],
      gameTitle: ['', [Validators.required]]
    });
  }

  // Function to submit the form
  onSubmit() {
    if (this.scoreForm.valid) {
      this.scoreService.addScore(this.scoreForm.value).subscribe(res =>{
        this.route.navigateByUrl('score-list');
      });
 
    } else {
      // Form is invalid, display error messages
      this.markFormGroupTouched(this.scoreForm);
    }
  }
  dateValidator(control: AbstractControl): ValidationErrors | null {
    const datePattern = /^\d{4}-\d{2}-\d{2}$/;
    if (!datePattern.test(control.value)) {
      return { invalidDate: true };
    }
    return null;
  }
  nonNegativeValidator(control:AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (value < 0) {
      return { 'negativeValue': true };
    }
    return null;
  }
  // Helper function to mark all controls in the form group as touched
  markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();

      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }
}
