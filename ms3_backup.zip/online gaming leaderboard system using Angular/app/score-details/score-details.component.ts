import { Component, Input, OnInit } from '@angular/core';

import { Observable, of } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { Score } from '../models/score';
import { ScoreService } from '../services/score.service';

@Component({
  selector: 'app-score-details',
  templateUrl: './score-details.component.html',
  styleUrls: ['./score-details.component.scss']
})
export class ScoreDetailsComponent implements OnInit {
  scores$: Observable<Score[]> = of([]);
  constructor(private scoreService: ScoreService,private route: ActivatedRoute){

  }
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      // Access parameters from the URL
      const id = params['id']; // Assuming your parameter is named 'id'
     this.getScore(id);
      
    });
   
  }
  getScore(id: any) {
    this.scores$ = this.scoreService.getScoreById(id);
  }

}
