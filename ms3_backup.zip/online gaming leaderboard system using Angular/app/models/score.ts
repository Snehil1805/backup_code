export interface Score {
    id?: number; 
    playerName: string;
    gameTitle: string;
    score: number;
    submissionDate:string,


}