import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ScoreListComponent } from './score-list/score-list.component';
import { ScoreDetailsComponent } from './score-details/score-details.component';
import { ScoreFormComponent } from './score-form/score-form.component';


const routes: Routes = [
  { path: 'score-list', component: ScoreListComponent },
  { path: 'score-details/:id', component: ScoreDetailsComponent },
  { path: 'score-form', component: ScoreFormComponent },
  { path: '', redirectTo: '/score-list', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
