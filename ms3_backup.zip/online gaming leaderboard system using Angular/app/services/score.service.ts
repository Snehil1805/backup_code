import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, map, Observable, throwError } from 'rxjs';

import { environment } from 'src/environments/environment';
import { Score } from '../models/score';

@Injectable({
  providedIn: 'root'
})
export class ScoreService {

  private apiUrl = environment.apiUrl; 

  constructor(private http: HttpClient) {}

  getScores(): Observable<any> {
    return this.http.get(`${this.apiUrl}/scores`);
  }

  addScore(score: Score): Observable<any> {
    return this.http.post(`${this.apiUrl}/scores`, score);
  }
  getScoreById(id: any): Observable<any[]> {
    return this.http.get(`${this.apiUrl}/scores/${id}`).pipe(
      map((data: any) => {
        // If the response is an array, return it as is
        if (Array.isArray(data)) {
          return data;
        } else {
          // If the response is a single object, wrap it in an array
          return [data];
        }
      })
    );
  }
}
