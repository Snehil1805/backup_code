import { Component, OnInit } from '@angular/core';
import { Score } from '../models/score';
import { Observable, map, of } from 'rxjs';
import { ScoreService } from '../services/score.service';

@Component({
  selector: 'app-score-list',
  templateUrl: './score-list.component.html',
  styleUrls: ['./score-list.component.scss']
})
export class ScoreListComponent implements OnInit {

  scores$: Observable<Score[]> = of([]);
  filteredscore$: Observable<Score[]> = of([]);

  searchQuery:any;
  constructor(private scoreService: ScoreService) { }

  ngOnInit(): void {
    this.getRecord();
  }
  getRecord() {
    this.scores$ = this.scoreService.getScores().pipe(
      map((scores: Score[]) => scores.sort((a, b) => a.playerName.localeCompare(b.playerName))) // Sort by playerName
    );
    this.filteredscore$=this.scores$;
  }
  searchPlayer(event: any) {
    debugger;
    const searchTerm = event.target.value.trim().toLowerCase();
    
    if (!searchTerm) {
      this.filteredscore$ = this.scores$;
      return;
    }
    
    this.filteredscore$ = this.scores$.pipe(
      map((score: Score[]) => {
        return score.filter((score) =>
        score.id?.toString().includes(searchTerm) || 
          (score.playerName.toLowerCase().includes(searchTerm))
        );
      })
    );
  }
  
}
