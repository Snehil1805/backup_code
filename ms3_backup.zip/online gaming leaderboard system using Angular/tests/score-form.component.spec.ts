import { ComponentFixture, TestBed, fakeAsync, tick } from "@angular/core/testing";
import { FormBuilder, ReactiveFormsModule } from "@angular/forms";

import { Router } from "@angular/router";

import { of } from "rxjs";
import { Score } from "src/app/models/score";
import { ScoreFormComponent } from "src/app/score-form/score-form.component";
import { ScoreService } from "src/app/services/score.service";

describe("ScoreFormComponent", () => {
  let component: ScoreFormComponent;
  let fixture: ComponentFixture<ScoreFormComponent>;
  let scoreService: jasmine.SpyObj<ScoreService>;
  let router: jasmine.SpyObj<Router>;

  beforeEach(() => {
    const scoreServiceSpy = jasmine.createSpyObj('ScoreService', ['addScore']); // Corrected the method name here
    const routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);
    TestBed.configureTestingModule({
      declarations: [ScoreFormComponent],
      imports: [ReactiveFormsModule],
      providers: [
        { provide: ScoreService, useValue: scoreServiceSpy },
        { provide: Router, useValue: routerSpy }
      ]
    });

    fixture = TestBed.createComponent(ScoreFormComponent);
    component = fixture.componentInstance;
    scoreService = TestBed.inject(ScoreService) as jasmine.SpyObj<ScoreService>;
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;
    component.ngOnInit();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should emit a score when the form is submitted with valid data",fakeAsync(() => {
    const formBuilder: FormBuilder = TestBed.inject(FormBuilder);
    const  scores:Score =
      {
      
        "playerName": "Luna",
        "gameTitle": "Race Mania",
        "score": 5000,
        "submissionDate": "2022-05-15 10:15 AM",
        "id":1
       
      }
    
    // Set up the form with valid data
    component.scoreForm = formBuilder.group({
      id: 1,
      playerName: [scores.playerName],
      gameTitle: [scores.gameTitle],
      submissionDate: [scores.submissionDate],
      score: [scores.score]
    });

    component.scoreForm.setValue(scores);

    // Stub the addLead method of the leadService to return an observable of empty object
    scoreService.addScore.and.returnValue(of({}));

    // Call onSubmit
    component.onSubmit();

    // Verify that addLead method was called with the correct data
    expect(scoreService.addScore).toHaveBeenCalledWith(scores);

    // Ensure router navigation has occurred
    expect(router.navigateByUrl).toHaveBeenCalledWith('score-list');

    // Advance the fakeAsync zone to ensure any asynchronous operations are complete
    tick();

    // Ensure router navigation has occurred
    expect(router.navigateByUrl).toHaveBeenCalledWith('score-list');
  }));
  it('should mark playerName control as invalid if empty', () => {
    const playerNameControl = component.scoreForm.get('playerName');
    playerNameControl?.setValue('');
    expect(playerNameControl?.valid).toBeFalsy();
  });

  it('should mark score control as invalid if negative', () => {
    const scoreControl = component.scoreForm.get('score');
    scoreControl?.setValue(-100);
    expect(scoreControl?.valid).toBeFalsy();
  });
});
