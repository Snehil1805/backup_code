import { TestBed } from "@angular/core/testing";
import { HttpClientTestingModule, HttpTestingController } from "@angular/common/http/testing";
import { ScoreService } from "src/app/services/score.service";
import { Score } from "src/app/models/score";
import { environment } from "src/environments/environment";

describe("ScoreService", () => {
  let service: ScoreService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ScoreService],
    });

    service = TestBed.inject(ScoreService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify(); // Verify that there are no outstanding HTTP requests.
  });

  it("should be created", () => {
    expect(service).toBeTruthy();
  });

  it("should retrieve scores from the API via GET", () => {
    const mockScores: Score[] = [
      {
        "id": 1,
        "playerName": "Ansh",
        "score": 100,
        "submissionDate": "2022-01-01",
        "gameTitle": "NO"
      },
    ];

    service.getScores().subscribe((scores: Score[]) => {
      expect(scores).toEqual(mockScores);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/scores`);
    expect(req.request.method).toBe("GET");
    req.flush(mockScores);
  });

  it("should add a score via POST", () => {
    const newScore: Score = {
      "id": 1,
      "playerName": "Ansh",
      "score": 100,
      "submissionDate": "2022-01-01",
      "gameTitle": "NO"
    }

    service.addScore(newScore).subscribe(() => {
      // Do any necessary assertions here
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/scores`);
    expect(req.request.method).toBe("POST");
    expect(req.request.body).toEqual(newScore);

    // Simulate a successful HTTP response
    req.flush({});
  });

  it("should retrieve a score by ID via GET", () => {
    const mockScore: Score[] = [{
      "id": 1,
      "playerName": "Ansh",
      "score": 100,
      "submissionDate": "2022-01-01",
      "gameTitle": "NO"
    }];

    service.getScoreById(1).subscribe((score) => {
      expect(score).toEqual(mockScore);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/scores/1`);
    expect(req.request.method).toBe("GET");
    req.flush(mockScore);
  });
});
