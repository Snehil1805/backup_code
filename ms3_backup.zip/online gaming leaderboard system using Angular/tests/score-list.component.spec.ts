import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';

import { ScoreListComponent } from '../app/score-list/score-list.component';
import { ScoreService } from '../app/services/score.service';
import { Score } from 'src/app/models/score';

describe('ScoreListComponent', () => {
  let component: ScoreListComponent;
  let fixture: ComponentFixture<ScoreListComponent>;
  let scoreService: jasmine.SpyObj<ScoreService>;

  beforeEach(async () => {
    scoreService = jasmine.createSpyObj('ScoreService', ['getScores']);

    await TestBed.configureTestingModule({
      declarations: [ScoreListComponent],
      providers: [{ provide: ScoreService, useValue: scoreService }]
    }).compileComponents();

    fixture = TestBed.createComponent(ScoreListComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fetch scores on ngOnInit', () => {
    const mockScores: Score[] = [
      { id: 1, playerName: 'Player 1', score: 100, submissionDate: '2022-01-01', gameTitle: 'NO' },
      { id: 2, playerName: 'Player 2', score: 150, submissionDate: '2022-01-01', gameTitle: 'NO' },
    ];
    scoreService.getScores.and.returnValue(of(mockScores));

    fixture.detectChanges();

    component.scores$.subscribe(scores => {
      expect(scores).toEqual(mockScores);
    });
  });

  it('should search Player', () => {
    const mockScores: Score[] = [
      { id: 1, playerName: 'Player 1', score: 100, submissionDate: '2022-01-01', gameTitle: 'NO' }
    ];

    scoreService.getScores.and.returnValue(of(mockScores));
    component.ngOnInit();

    component.searchPlayer({ target: { value: "Player 1" } });

    component.filteredscore$.subscribe((filteredScores) => {
      expect(filteredScores.length).toBe(1);
      expect(filteredScores[0].playerName).toBe("Player 1");
    });
  });

  it('should sort scores by playerName in ascending order', () => {
    const unsortedScores: Score[] = [
      { id: 1, playerName: 'Charlie', score: 120, submissionDate: '2022-01-01', gameTitle: 'NO' },
      { id: 2, playerName: 'Alice', score: 130, submissionDate: '2022-01-01', gameTitle: 'NO' },
      { id: 3, playerName: 'Bob', score: 110, submissionDate: '2022-01-01', gameTitle: 'NO' },
    ];
    const sortedScores: Score[] = [
      { id: 2, playerName: 'Alice', score: 130, submissionDate: '2022-01-01', gameTitle: 'NO' },
      { id: 3, playerName: 'Bob', score: 110, submissionDate: '2022-01-01', gameTitle: 'NO' },
      { id: 1, playerName: 'Charlie', score: 120, submissionDate: '2022-01-01', gameTitle: 'NO' },
    ];

    scoreService.getScores.and.returnValue(of(unsortedScores));
    component.ngOnInit();

    component.scores$.subscribe(scores => {
      expect(scores).toEqual(sortedScores);
    });
  });
});
