import { ComponentFixture, TestBed } from "@angular/core/testing";
import { map, of, throwError } from "rxjs";

import { ShipmentListComponent } from "../app/shipment-list/shipment-list.component";
import { ShipmentService } from "../app/services/shipment.service";
import { Shipment } from "src/app/models/Shipment";
import { ShipmentDetailsComponent } from "src/app/shipment-details/shipment-details.component";
import { ShipmentFormComponent } from "src/app/shipment-form/shipment-form.component";

describe("ShipmentListComponent", () => {
  let component: ShipmentListComponent;
  let fixture: ComponentFixture<ShipmentListComponent>;
  let shipmentService: jasmine.SpyObj<ShipmentService>;

  beforeEach(() => {
    shipmentService = jasmine.createSpyObj("ShipmentService", [
      "getShipments",
      "addShipment",
    ]);

    TestBed.configureTestingModule({
      declarations: [
        ShipmentListComponent,
        ShipmentFormComponent,
        ShipmentDetailsComponent,
      ],
      providers: [{ provide: ShipmentService, useValue: shipmentService }],
    });

    fixture = TestBed.createComponent(ShipmentListComponent);
    component = fixture.componentInstance;
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should fetch shipments on ngOnInit", () => {
    const mockShipments: Shipment[] = [
      {
        id: 1,
        sender: "Tech Corp",
        receiver: "Jane Doe",
        origin: "New York",
        destination: "San Francisco",
        status: "In Transit",
        expectedDelivery: "2023-09-20",
      },
      {
        id: 2,
        sender: "John Smith",
        receiver: "Books Store",
        origin: "Los Angeles",
        destination: "Chicago",
        status: "Delivered",
        expectedDelivery: "2023-09-10",
      },
    ];

    shipmentService.getShipments.and.returnValue(of(mockShipments));

    fixture.detectChanges(); // Trigger ngOnInit

    expect(component.shipments$).toBeTruthy();
    component.shipments$.subscribe((shipments: Shipment[]) => {
      expect(shipments).toEqual(mockShipments);
    });
  });

  it("should handle errors when fetching shipments on ngOnInit", () => {
    shipmentService.getShipments.and.returnValue(throwError("Error"));

    fixture.detectChanges(); // Trigger ngOnInit

    expect(component.shipments$).toBeTruthy();
    component.shipments$.subscribe({
      error: (error: any) => {
        expect(error).toEqual("Error");
      },
    });
  });

  it("should sort shipments by sender in ascending order", () => {
    const mockShipments: Shipment[] = [
      {
        id: 1,
        sender: "Tech Corp",
        receiver: "Jane Doe",
        origin: "New York",
        destination: "San Francisco",
        status: "In Transit",
        expectedDelivery: "2023-09-20",
      },
      {
        id: 2,
        sender: "John Smith",
        receiver: "Books Store",
        origin: "Los Angeles",
        destination: "Chicago",
        status: "Delivered",
        expectedDelivery: "2023-09-10",
      },
      {
        id: 3,
        sender: "Alpha Inc",
        receiver: "Tech Corp",
        origin: "Boston",
        destination: "New York",
        status: "In Transit",
        expectedDelivery: "2023-09-25",
      },
    ];

    shipmentService.getShipments.and.returnValue(of(mockShipments));

    fixture.detectChanges(); // Trigger ngOnInit

    component.filterdShipments$.subscribe((shipments: Shipment[]) => {
      expect(shipments[0].sender).toBe("Alpha Inc");
      expect(shipments[1].sender).toBe("John Smith");
      expect(shipments[2].sender).toBe("Tech Corp");
    });
  });

  it("should search shipments", () => {
    const mockShipments: Shipment[] = [
      {
        id: 1,
        sender: "Tech Corp",
        receiver: "Jane Doe",
        origin: "New York",
        destination: "San Francisco",
        status: "In Transit",
        expectedDelivery: "2023-09-20",
      },
      {
        id: 2,
        sender: "John Smith",
        receiver: "Books Store",
        origin: "Los Angeles",
        destination: "Chicago",
        status: "Delivered",
        expectedDelivery: "2023-09-10",
      },
    ];

    shipmentService.getShipments.and.returnValue(of(mockShipments));
    component.ngOnInit();

    component.searchShipments({ target: { value: "Chicago" } });

    component.filterdShipments$.subscribe((filteredShipments) => {
      expect(filteredShipments.length).toBe(1);
      expect(filteredShipments[0].sender).toBe("John Smith");
    });
  });
});
