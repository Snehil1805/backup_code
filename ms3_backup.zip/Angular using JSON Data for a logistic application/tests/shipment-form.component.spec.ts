import { ComponentFixture, TestBed, tick } from "@angular/core/testing";
import { FormBuilder, ReactiveFormsModule } from "@angular/forms";
import { ShipmentFormComponent } from "../app/shipment-form/shipment-form.component";
import { ShipmentService } from "src/app/services/shipment.service";
import { Router } from "@angular/router";
import { of } from "rxjs";

describe("ShipmentFormComponent", () => {
  let component: ShipmentFormComponent;
  let fixture: ComponentFixture<ShipmentFormComponent>;
  let shipmentService: jasmine.SpyObj<ShipmentService>;
  let router: jasmine.SpyObj<Router>;

  beforeEach(() => {
    const shipmentServiceSpy = jasmine.createSpyObj('ShipmentService', ['addShipment']);
    const routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);
    
    TestBed.configureTestingModule({
      declarations: [ShipmentFormComponent],
      imports: [ReactiveFormsModule],
      providers: [
        { provide: ShipmentService, useValue: shipmentServiceSpy },
        { provide: Router, useValue: routerSpy }
      ]
    });

    fixture = TestBed.createComponent(ShipmentFormComponent);
    component = fixture.componentInstance;

    // Initialize the spies
    shipmentService = TestBed.inject(ShipmentService) as jasmine.SpyObj<ShipmentService>;
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should emit a shipment when the form is submitted with valid data", () => {
    const formBuilder: FormBuilder = TestBed.inject(FormBuilder);
    const shipment = {
      id: 1,
      sender: "Tech Corp",
      receiver: "Jane Doe",
      origin: "New York",
      destination: "San Francisco",
      status: "In Transit",
      expectedDelivery: "2023-09-20",
    };

    // Set up the form with valid data
    component.shipmentForm = formBuilder.group({
      id: 1,
      sender: [shipment.sender],
      receiver: [shipment.receiver],
      origin: [shipment.origin],
      destination: [shipment.destination],
      status: [shipment.status],
      expectedDelivery: [shipment.expectedDelivery],
    });

    // Stub the addShipment method of the shipmentService to return an observable of empty object
    shipmentService.addShipment.and.returnValue(of({}));

    // Call submitForm
    component.onSubmit();

    // Verify that addShipment method was called with the correct data
    expect(shipmentService.addShipment).toHaveBeenCalledWith(shipment);

    // Ensure router navigation has occurred
    expect(router.navigateByUrl).toHaveBeenCalledWith('/shipment-list');

    // No need to use tick() as there are no asynchronous operations in this test case
  });
});
