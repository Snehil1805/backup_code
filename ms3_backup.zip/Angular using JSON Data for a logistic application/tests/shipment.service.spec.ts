import { TestBed, inject } from "@angular/core/testing";
import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";

import { ShipmentService } from "../app/services/shipment.service";
import { Shipment } from "../app/models/Shipment";
import { environment } from "src/environments/environment";

describe("Shipment", () => {
  let service: ShipmentService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ShipmentService],
    });

    service = TestBed.inject(ShipmentService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify(); // Verify that there are no outstanding HTTP requests.
  });

  it("should be created", () => {
    expect(service).toBeTruthy();
  });

  it("should retrieve shipments from the API via GET", () => {
    const mockShipments: Shipment[] = [
      {
        id: 1,
        sender: "Tech Corp",
        receiver: "Jane Doe",
        origin: "New York",
        destination: "San Francisco",
        status: "In Transit",
        expectedDelivery: "2023-09-20",
      },
      {
        id: 2,
        sender: "John Smith",
        receiver: "Books Store",
        origin: "Los Angeles",
        destination: "Chicago",
        status: "Delivered",
        expectedDelivery: "2023-09-10",
      },
    ];

    service.getShipments().subscribe((shipments: Shipment[]) => {
      expect(shipments).toEqual(mockShipments);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/shipments`);
    expect(req.request.method).toBe("GET");
    req.flush(mockShipments);
  });

  it("should add a shipment via POST", () => {
    const newShipment: Shipment = {
      id: 1,
      sender: "Tech Corp",
      receiver: "Jane Doe",
      origin: "New York",
      destination: "San Francisco",
      status: "In Transit",
      expectedDelivery: "2023-09-20",
    };

    service.addShipment(newShipment).subscribe(() => {
      // Do any necessary assertions here
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/shipments`);
    expect(req.request.method).toBe("POST");
    expect(req.request.body).toEqual(newShipment);

    // Simulate a successful HTTP response
    req.flush({});
  });

  it("should retrieve a shipment by ID via GET", () => {
    const mockShipment: Shipment = {
      id: 1,
      sender: "Tech Corp",
      receiver: "Jane Doe",
      origin: "New York",
      destination: "San Francisco",
      status: "In Transit",
      expectedDelivery: "2023-09-20",
    };

    service.getShipment(1).subscribe((shipment: Shipment) => {
      expect(shipment.id).toEqual(mockShipment.id);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/shipments/1`);
    expect(req.request.method).toBe("GET");
    req.flush(mockShipment);
  });
});
