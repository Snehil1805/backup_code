import { Component, EventEmitter, OnInit, Output } from "@angular/core";
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  ValidationErrors,
  Validators,
} from "@angular/forms";
import { Shipment } from "../models/Shipment";
import { ShipmentService } from "../services/shipment.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-shipment-form",
  templateUrl: "./shipment-form.component.html",
  styleUrls: ["./shipment-form.component.scss"],
})
export class ShipmentFormComponent implements OnInit {
  shipmentForm: FormGroup;
  shipmentStatus = ['Pending', 'In Transit', 'Delivered'];


  constructor(private fb: FormBuilder,private shipmentService:ShipmentService, private router:Router ) {}

  ngOnInit(): void {
    // Initialize the form with validators
    this.shipmentForm = this.fb.group({
      sender: ["", [Validators.required]],
      receiver: ["", [Validators.required, Validators.min(1)]],
      origin: ["", [Validators.required]],
      destination: ["", [Validators.required]],
      status: [this.shipmentStatus[0]],
      expectedDelivery: ["", [Validators.required, this.dateValidator]],
    });
  }

  dateValidator(control: AbstractControl): ValidationErrors | null {
    const datePattern = /^\d{4}-\d{2}-\d{2}$/;

    if (!datePattern.test(control.value)) {
      return { invalidDate: true };
    }

    return null;
  }

  // Function to submit the form
  onSubmit() {
    if (this.shipmentForm.valid) {
      // Form is valid, you can submit it
      this.shipmentService.addShipment(this.shipmentForm.value).subscribe((res) => {
        this.router.navigateByUrl('/shipment-list')
      });
    } else {
      // Form is invalid, display error messages
      this.markFormGroupTouched(this.shipmentForm);
    }
  }

  // Helper function to mark all controls in the form group as touched
  markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach((control) => {
      control.markAsTouched();

      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }
}
