import { Component, OnInit } from '@angular/core';
import { Observable, map, of } from 'rxjs';
import { Shipment } from '../models/Shipment';
import { ShipmentService } from '../services/shipment.service';

@Component({
  selector: 'app-shipment-list',
  templateUrl: './shipment-list.component.html',
  styleUrls: ['./shipment-list.component.scss']
})
export class ShipmentListComponent implements OnInit {
  filterdShipments$: Observable<Shipment[]> = of([]);
  shipments$: Observable<Shipment[]> = of([]);
 

  constructor(private shipmentService: ShipmentService) { }

  ngOnInit(): void {
    this.getShipments();
  }



  getShipments() {
    this.shipments$ = this.shipmentService.getShipments().pipe(
      map((shipments) => {
        return shipments.sort((a:any, b:any) => {
          // Sorting by sender in ascending order
          return a.sender.localeCompare(b.sender);
        });
      })
    );
    this.filterdShipments$ = this.shipments$;
  }

  searchShipments(event: any) {
    const searchTerm = event.target.value.trim();
    if (!searchTerm) {
      this.filterdShipments$ = this.shipments$;
      return;
    }
    this.filterdShipments$ = this.shipments$.pipe(
      map((shipments) => {
        return shipments.filter(
          (shipment) =>
            shipment.id.toString().includes(searchTerm) ||
            shipment.destination.includes(searchTerm)
        );
      })
    );
  }

}
