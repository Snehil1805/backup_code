import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Shipment } from '../models/Shipment';
@Injectable({
  providedIn: 'root'
})
export class ShipmentService {

  private apiUrl = environment.apiUrl; 

  constructor(private http: HttpClient) {}

  getShipments(): Observable<any> {
    return this.http.get(`${this.apiUrl}/shipments`);
  }

  getShipment(id: number): any {
    return this.http.get(`${this.apiUrl}/shipments/${id}`);
  }

  addShipment(shipment: Shipment): Observable<any> {
    return this.http.post(`${this.apiUrl}/shipments`, shipment);
  }
  getShipmentbyId(id: any): Observable<any[]> {
    return this.http.get(`${this.apiUrl}/shipments/${id}`).pipe(
      map((data: any) => {
        // If the response is an array, return it as is
        if (Array.isArray(data)) {
          return data;
        } else {
          // If the response is a single object, wrap it in an array
          return [data];
        }
      })
    );
  }
}
