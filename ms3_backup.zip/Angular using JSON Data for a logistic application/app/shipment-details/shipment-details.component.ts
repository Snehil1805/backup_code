import { Component, Input, OnInit } from '@angular/core';
import { Shipment } from '../models/Shipment';
import { Observable, of } from 'rxjs';
import { ShipmentService } from '../services/shipment.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-shipment-details',
  templateUrl: './shipment-details.component.html',
  styleUrls: ['./shipment-details.component.scss']
})
export class ShipmentDetailsComponent implements OnInit {
  shipments$: Observable<Shipment[]> = of([]);

  constructor(private shipmentService: ShipmentService,private route: ActivatedRoute){

  }
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      // Access parameters from the URL
      const id = params['id']; // Assuming your parameter is named 'id'
     this.getShipment(id);
      
    });
   
  }
  getShipment(id: any) {
    this.shipments$ = this.shipmentService.getShipmentbyId(id);
  }
}