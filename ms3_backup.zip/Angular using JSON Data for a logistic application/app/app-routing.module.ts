import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ShipmentDetailsComponent } from './shipment-details/shipment-details.component';
import { ShipmentListComponent } from './shipment-list/shipment-list.component';
import { ShipmentFormComponent } from './shipment-form/shipment-form.component';




const routes: Routes = [
  { path: 'shipment-list', component: ShipmentListComponent },
  { path: 'shipment-details/:id', component: ShipmentDetailsComponent },
  { path: 'shipment-form', component: ShipmentFormComponent },
  { path: '', redirectTo: '/shipment-list', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
