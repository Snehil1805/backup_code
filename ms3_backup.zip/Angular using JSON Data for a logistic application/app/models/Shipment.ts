export interface Shipment {
  id: number;
  sender: string;
  receiver: string;
  origin: string;
  destination: string;
  status: string;
  expectedDelivery: string;
}
